package com.javainuse.springboothelloworld1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootHelloworld1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
